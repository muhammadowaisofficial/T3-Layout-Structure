export default function ServiceLayout({ children }: React.PropsWithChildren<{}>) {
 return (
   <>
    <h1>Header</h1>
     <main className="flex-grow">{children}</main>
     <h1>Footer</h1>
   </>
 );
}
