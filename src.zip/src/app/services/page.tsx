export default function ServicePage() {
  return (
    <>
    <h1>Service Page Inner</h1>
    </>
  );
}
