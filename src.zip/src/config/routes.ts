export const Routes = {
    public: {
    home: '/',
    about: '/about',
    notFound: '/404',
  }
};
