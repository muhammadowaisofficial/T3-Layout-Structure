export const Routes = {
    public: {
    home: '/',
    about: '/about',
    services: '/services',
    notFound: '/404',
  }
};
